from django import forms
from .models import Student
from django.core.validators import MinValueValidator, MaxValueValidator
import datetime
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django_recaptcha.fields import ReCaptchaField


class StudentForm(forms.ModelForm):
    class Meta:
        model = Student
        fields = [
            'student_number',
            'first_name',
            'last_name',
            'email',
            'field_of_study',
            'cgpa',
            'date_of_birth',
        ]
        labels = {
            'student_number': 'Student ID',
            'first_name': 'First Name',
            'last_name': 'Last Name',
            'email': 'Email Address',
            'field_of_study': 'Major / Field of Study',
            'cgpa': 'CGPA',
            'date_of_birth': 'Date of Birth',
        }
        help_texts = {
            'cgpa': 'Enter CGPA between 0.0 and 10.0',
            'email': 'Must be a valid email address',
            'date_of_birth': 'Format: YYYY-MM-DD',
        }
        widgets = {
            'student_number': forms.TextInput(attrs={'class': 'form-control'}),
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'field_of_study': forms.TextInput(attrs={'class': 'form-control'}),
            'cgpa': forms.NumberInput(attrs={'class': 'form-control', 'step': '0.01'}),
            'date_of_birth': forms.DateInput(attrs={'class': 'form-control', 'type': 'date'}),
        }

    def clean_cgpa(self):
        cgpa = self.cleaned_data.get('cgpa')
        if cgpa < 0.0 or cgpa > 10.0:
            raise forms.ValidationError('CGPA must be between 0.0 and 10.0')
        return cgpa

    def clean_date_of_birth(self):
        dob = self.cleaned_data.get('date_of_birth')
        if dob > datetime.date.today():
            raise forms.ValidationError('Date of birth cannot be in the future.')
        return dob

class RegisterForm(UserCreationForm):
    email = forms.EmailField(
        required=True,
        widget=forms.EmailInput(attrs={'class': 'form-control'}),
    )

    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']
        widgets = {
            'username': forms.TextInput(attrs={'class': 'form-control'}),
            'password1': forms.PasswordInput(attrs={'class': 'form-control'}),
            'password2': forms.PasswordInput(attrs={'class': 'form-control'}),
        }
    def __init__(self, *args, **kwargs):
        super(RegisterForm, self).__init__(*args, **kwargs)
        self.fields['password1'].widget.attrs.update({'class': 'form-control'})
        self.fields['password2'].widget.attrs.update({'class': 'form-control'})    
    def clean_email(self):
        email = self.cleaned_data.get('email')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError("This email address is already registered.")
        return email




class LoginFormWithCaptcha(AuthenticationForm):
    captcha = ReCaptchaField()

# forms.py
from django.contrib.auth.forms import PasswordResetForm
from django.core.exceptions import ValidationError
from django.contrib.auth.models import User

class CustomPasswordResetForm(PasswordResetForm):
    def clean_email(self):
        email = self.cleaned_data['email']
        if not User.objects.filter(email=email).exists():
            raise ValidationError("No user is registered with this email address.")
        return email
