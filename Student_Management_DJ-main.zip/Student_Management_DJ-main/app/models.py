from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Student(models.Model):
    staff_name=models.ForeignKey(User, on_delete=models.CASCADE)
    student_number=models.CharField(max_length=10, unique=True)
    first_name=models.CharField(max_length=30)
    last_name=models.CharField(max_length=30)
    email=models.EmailField(max_length=33, unique=True)
    field_of_study=models.CharField(max_length=99)
    cgpa=models.DecimalField(max_digits=3, decimal_places=2)
    date_of_birth=models.DateField()
    
    def __str__(self):
        return f"Student:{self.first_name} {self.last_name}"