from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Student
from .forms import StudentForm, RegisterForm, LoginFormWithCaptcha
from django.contrib.auth import login, authenticate, logout

from django.contrib.auth.decorators import login_required
from django.contrib import messages


# views.py
from django.contrib.auth.views import PasswordResetView
from .forms import CustomPasswordResetForm

# --------------------------
# Registration View
# --------------------------
def register_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == "POST":
        form = RegisterForm(request.POST)
        if form.is_valid():
            form.save()
            username = form.cleaned_data['username']
            password = form.cleaned_data['password1']
            user = authenticate(username=username, password=password)
            login(request, user)
            
            # ✅ Store welcome flag in session
            request.session['new_user'] = True

            messages.success(request, "Registration successful. Welcome!")
            return redirect('index')
    else:
        form = RegisterForm()

    return render(request, 'app/register.html', {'form': form})


# --------------------------
# Login View
# --------------------------
from .forms import LoginFormWithCaptcha

def user_login(request):
    if request.method == 'POST':
        form = LoginFormWithCaptcha(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)

            # Optional: remember_me session
            if request.POST.get('remember_me'):
                request.session.set_expiry(60 * 60 * 24 * 7)
            else:
                request.session.set_expiry(0)

            messages.success(request, "Logged in successfully.")
            return redirect('index')
    else:
        form = LoginFormWithCaptcha()
    return render(request, 'app/login.html', {'form': form})


# --------------------------
# Logout View
# --------------------------
def user_logout(request):
    # request.session.flush()  # ✅ Clear all session data (full reset)
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')


# --------------------------
# Index Page - Show Students
# --------------------------
@login_required
def index(request):
    # ✅ Session example: Show welcome message once
    if request.session.get('new_user'):
        messages.success(request, "Welcome to the dashboard!")
        request.session.pop('new_user')  # Remove after showing once

    # ✅ Example: Keep track of last page visited
    request.session['last_page'] = 'index'

    students = Student.objects.filter(staff_name=request.user)
    return render(request, 'app/index.html', {'students': students})


# --------------------------
# View Student
# --------------------------
@login_required
def view_student(request, id):
    request.session['last_viewed_student_id'] = id  # ✅ Store for reference
    student = Student.objects.get(id=id)
    return render(request, 'app/view_student.html', {'student': student})


# --------------------------
# Add Student
# --------------------------
@login_required
def add(request):
    if request.method == "POST":
        form = StudentForm(request.POST)
        if form.is_valid():
            student = form.save(commit=False)
            student.staff_name = request.user
            student.save()

            messages.success(request, "Student added successfully!")
            return redirect('index')
    else:
        form = StudentForm()

    return render(request, 'app/addstudent.html', {'form': form})


# --------------------------
# Edit Student
# --------------------------
@login_required
def edit(request, id):
    student = Student.objects.get(id=id)

    # ✅ Access protection: only owner can edit
    if student.staff_name != request.user:
        messages.warning(request, "Access denied: Not your student.")
        return redirect('index')

    if request.method == 'POST':
        form = StudentForm(request.POST, instance=student)
        if form.is_valid():
            form.save()
            messages.success(request, "Student updated successfully.")
            return redirect('index')
    else:
        form = StudentForm(instance=student)

    return render(request, 'app/edit.html', {'form': form})


# --------------------------
# Delete Student
# --------------------------
@login_required
def delete(request, id):
    student = Student.objects.get(id=id)

    # ✅ Protect: Only owner can delete
    if student.staff_name != request.user:
        messages.warning(request, "You cannot delete this record.")
        return redirect('index')

    student.delete()
    messages.success(request, "Student deleted.")
    return redirect('index')


def debug_session_view(request):
    for key, value in request.session.items():
        print(f"{key}: {value}")  # Printed in terminal
    return HttpResponse("Session data printed in console.")



class CustomPasswordResetView(PasswordResetView):
    form_class = CustomPasswordResetForm
    template_name = 'app/password_reset.html'
