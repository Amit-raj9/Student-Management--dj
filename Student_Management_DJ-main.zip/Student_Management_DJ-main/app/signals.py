from django.contrib.auth.signals import user_logged_in, user_logged_out, user_login_failed
from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver
import logging

logger = logging.getLogger(__name__)

# User registration signal
@receiver(post_save, sender=User)
def user_registered(sender, instance, created, **kwargs):
    if created:
        print(f"✅ New user registered: {instance.username}")
        logger.info(f"User registered: {instance.username}")

# User login signal
@receiver(user_logged_in)
def user_logged_in_handler(sender, request, user, **kwargs):
    print(f"🔓 User logged in: {user.username}")
    logger.info(f"User logged in: {user.username}")

# User logout signal
@receiver(user_logged_out)
def user_logged_out_handler(sender, request, user, **kwargs):
    print(f"🔒 User logged out: {user.username}")
    logger.info(f"User logged out: {user.username}")

# Login failed
@receiver(user_login_failed)
def login_failed_handler(sender, credentials, **kwargs):
    print(f"❌ Login failed for: {credentials.get('username')}")
    logger.warning(f"Login failed for: {credentials.get('username')}")
